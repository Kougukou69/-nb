appname="Java方法浏览器"
appver="1.0"
packagename="com.androlua.JavaAPI"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
