appname="name"
appver="1.2"
packagename="com.elua.demo"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
