软件使用开源编辑器OpenLuaX+开发
OpenLuaX+是基于开源框架AndroLua+开发的编辑器
使用本软件产生的任何后果均与AndroLua+及作者无关
使用本软件产生的任何后果均与OpenLuaX+及作者无关
AndroLua+的github地址:
https://github.com/nirenr/AndroLua_pro
reOpenLua+的github地址:
https://github.com/daisukiKaffuChino/reOpenLua-Open-Source
