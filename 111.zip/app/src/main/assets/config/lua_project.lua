last_file_path="/storage/emulated/0/AndroLua/new.lua"
last_file_cursor=0