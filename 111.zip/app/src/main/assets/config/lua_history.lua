last_history={
  ["/storage/emulated/0/AndroLua/new.lua"]	= 0;
  };